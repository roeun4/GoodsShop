-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: testdb
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `c_category`
--

DROP TABLE IF EXISTS `c_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `c_category` (
  `cnum` int NOT NULL AUTO_INCREMENT,
  `code` varchar(10) NOT NULL,
  `cname` varchar(20) NOT NULL,
  PRIMARY KEY (`cnum`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `c_category`
--

LOCK TABLES `c_category` WRITE;
/*!40000 ALTER TABLE `c_category` DISABLE KEYS */;
INSERT INTO `c_category` VALUES (1,'DT','디지털/테크'),(2,'Frame','액자'),(3,'animal','애견'),(4,'Kids','키즈'),(6,'Living','리빙'),(7,'Sticker','스티커'),(8,'PhoneA','폰액세서리'),(9,'office','문구/오피스'),(10,'cushion','쿠션/패브릭'),(11,'fashion','패션잡화'),(12,'goods','굿즈'),(13,'Apparel','의류');
/*!40000 ALTER TABLE `c_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notice`
--

DROP TABLE IF EXISTS `notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notice` (
  `no` int NOT NULL AUTO_INCREMENT,
  `writer` varchar(20) DEFAULT NULL,
  `title` varchar(40) NOT NULL,
  `content` varchar(2000) NOT NULL,
  `InDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`no`),
  KEY `writer` (`writer`),
  CONSTRAINT `notice_ibfk_1` FOREIGN KEY (`writer`) REFERENCES `sadmin` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notice`
--

LOCK TABLES `notice` WRITE;
/*!40000 ALTER TABLE `notice` DISABLE KEYS */;
INSERT INTO `notice` VALUES (2,NULL,'아무말이나 적고 확인해보는 테스트용 공지사항임','아아아아','2024-02-23 11:58:53'),(3,NULL,'1 공지사항','h','2024-02-23 12:37:29'),(4,NULL,'2 공지사항','ㅁㅀㅁㅇㅎ','2024-02-23 12:37:35'),(5,NULL,'3 공지사항','ㅁㅎㄴㅇㅎㅁㄹ','2024-02-23 12:37:43'),(6,NULL,'4 공지사항','ㅁㅎㄹㅇㅎ','2024-02-23 12:39:13'),(7,NULL,'5 공지사항','ㅇㅁㅎㄹ','2024-02-23 12:39:21'),(8,NULL,'6 공지사항','ㅁㅎㄹ놓','2024-02-23 12:39:27'),(9,NULL,'7 공지사항','ㅁㅇㅁㄹㄴㅇ','2024-02-23 12:39:38'),(10,NULL,'8 공지사항','ㅎㄻㅇㅎ','2024-02-23 12:39:44'),(11,NULL,'9 공지사항','ㅇㅀ','2024-02-23 12:39:50'),(12,NULL,'10 공지사항','ㅁㄴㅇㅎㅁㄹ','2024-02-23 12:39:58'),(13,NULL,'11 공지사항','ㅁㅀ','2024-02-23 12:40:08'),(14,NULL,'14 공지사항','ㅁㅎㅇ','2024-02-23 12:40:39'),(15,NULL,'15 공지사항','ㅁㅇㅎ','2024-02-23 12:40:50'),(17,NULL,'17 공지사항','ㅀㅁㄹ','2024-02-23 12:41:09'),(24,NULL,'공지사항','내용','2024-02-28 10:19:13');
/*!40000 ALTER TABLE `notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sadmin`
--

DROP TABLE IF EXISTS `sadmin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sadmin` (
  `ano` int NOT NULL AUTO_INCREMENT,
  `aid` varchar(50) NOT NULL,
  `apassword` varchar(100) NOT NULL,
  `name` varchar(20) NOT NULL,
  PRIMARY KEY (`ano`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sadmin`
--

LOCK TABLES `sadmin` WRITE;
/*!40000 ALTER TABLE `sadmin` DISABLE KEYS */;
INSERT INTO `sadmin` VALUES (1,'admin','1234','관리자');
/*!40000 ALTER TABLE `sadmin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scart`
--

DROP TABLE IF EXISTS `scart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `scart` (
  `cart_no` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `pno` int NOT NULL,
  `pqty` int DEFAULT '1',
  `price` int DEFAULT NULL,
  `cartInDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`cart_no`),
  KEY `username` (`username`),
  KEY `pno` (`pno`),
  CONSTRAINT `scart_ibfk_1` FOREIGN KEY (`username`) REFERENCES `suser` (`username`),
  CONSTRAINT `scart_ibfk_2` FOREIGN KEY (`pno`) REFERENCES `sproduct` (`pno`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scart`
--

LOCK TABLES `scart` WRITE;
/*!40000 ALTER TABLE `scart` DISABLE KEYS */;
INSERT INTO `scart` VALUES (1,'user1',12,1,0,'2024-02-22 11:24:52');
/*!40000 ALTER TABLE `scart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sproduct`
--

DROP TABLE IF EXISTS `sproduct`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sproduct` (
  `pno` int NOT NULL AUTO_INCREMENT,
  `pname` varchar(100) NOT NULL,
  `pcate_fk` varchar(20) DEFAULT NULL,
  `pimage` varchar(200) DEFAULT NULL,
  `pcompany` varchar(50) DEFAULT NULL,
  `delivery` int NOT NULL DEFAULT '0',
  `price` int NOT NULL DEFAULT '0',
  `pspec` varchar(20) DEFAULT NULL,
  `pcontent` varchar(300) DEFAULT NULL,
  `in_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pno`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sproduct`
--

LOCK TABLES `sproduct` WRITE;
/*!40000 ALTER TABLE `sproduct` DISABLE KEYS */;
INSERT INTO `sproduct` VALUES (12,'ㅇㄹ','의류','workplace-2303851_1920.jpg','나누',5000,30000,'일반','fvjh','2024-01-31 12:49:27'),(13,'비타민','디지털/테크','thumb-66CI66qs7I2464Sk7J28_6_276x276.jpg','TEAZEN',3000,13900,'인기','ㅁㅇㄹ','2024-02-02 15:21:32'),(14,'친환경 키친타올','리빙','thumb-09_276x276.jpg','나누',3000,15000,'인기','ㅁㅇㄹ','2024-02-02 15:22:19'),(15,'박','스티커','granola_320x340.jpg','LG',1000,12500,'일반','ㅇㅁㄹ','2024-02-02 15:26:46'),(16,'쿠키박스','문구/오피스','thumb-7L2U7L2U64Sb7I2464Sk7J28_6_276x276.jpg','바스틀리',1000,12900,'최신','ㅁㅇㄹ','2024-02-02 16:48:53'),(17,'대나무','폰액세서리','thumb-64KY64iE64yA6c_276x276.jpg','아임에코',2000,8900,'추천','ㄴㅁㅇㄹ','2024-02-02 16:49:30'),(18,'ㅇㄴㅁㄹ','패션잡화','thumb-65GQ7Jyg_276x276.jpg','TEN',2000,15048,'추천','ㅁㅇㄴㄹ','2024-02-02 16:50:00'),(19,'ㅇㅁㄹ','패션잡화','thumb-7I2464Sk7J281_276x276.jpg','ㅁㅇㄴㄹ',158,84,'최신','ㅁㄹㅇ','2024-02-02 16:50:16'),(20,'초코파이','스티커','thumb-knola1007IiY7KCc7IaM200g_276x276.jpg','나누',3000,5000,'일반','ㅗㅓ','2024-02-26 11:03:15'),(24,'노트북','디지털/테크','1000000662_main_045.jpg','TEAZEN',5000,159000,'인기','ㅁㅇㄹ','2024-02-26 13:33:00'),(25,'물병','리빙','thumb-6rOg66eI7Jq07IOY_276x276.png','바스티',2000,9900,'인기','ㅇㅁㄶ','2024-02-26 17:10:31'),(26,'종이','문구/오피스','thumb-67CA7YKk7JqU7IiY7KCcF_276x276.jpg','per',1500,3000,'인기','adsg','2024-02-26 17:22:05'),(27,'콤부차 스티커 10매','스티커','thumb-TEAZEN_PEACHE_276x276.jpg','TEAZEN',1000,3500,'최신','ㅁㅇㅎ','2024-02-26 17:44:41'),(28,'리얼한 김치 쿠션','쿠션/패브릭','thumb-7JuM7Luk7Z6Q7Zi47YWU7JuM7Luk7Z6Q7Zi47YWU7Ys6riw6rmA7LmY_276x276.jpg','나도몰라',1500,21000,'최신','ㅁㅇㅎ','2024-02-26 17:47:57'),(29,'라벨','스티커','thumb-6rCA67K87Jq07IOY1L7I2464Sk7J28_276x276.jpg','라라라',1000,2300,'최신','ㅁㅇㅎ','2024-02-26 17:48:49'),(30,'아라','의류','thumb-thum_7YKk7Lmc7YOA7JuU7J2867CY7ZiV2_276x276.jpg','라라라',1500,35000,'인기','ㅁㅇㄶ','2024-02-27 09:47:13');
/*!40000 ALTER TABLE `sproduct` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suser`
--

DROP TABLE IF EXISTS `suser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `suser` (
  `no` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `name` varchar(20) NOT NULL,
  `dob` int NOT NULL,
  `email` varchar(200) NOT NULL,
  `tel` int NOT NULL,
  `inDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`no`,`username`),
  UNIQUE KEY `id_UNIQUE` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suser`
--

LOCK TABLES `suser` WRITE;
/*!40000 ALTER TABLE `suser` DISABLE KEYS */;
INSERT INTO `suser` VALUES (1,'user1','1234','강인',20000856,'afdaf@gmail.com',10556465,'2024-02-07 16:56:39'),(2,'test','12345','홍길동',20000856,'test2@nave',10556465,'2024-02-21 10:24:22'),(8,'user1e','12345','이리지',19901008,'afg@adg',10556465,'2024-02-28 10:02:59'),(9,'test3','12345','황인기',20000856,'adf@dg',123456,'2024-02-28 12:41:25'),(10,'test4','123456','홍길동',20000856,'adf@gd',123456,'2024-02-28 12:43:23'),(11,'test1','12345','황길동',20000856,'adf@gd',123456,'2024-02-28 12:44:15');
/*!40000 ALTER TABLE `suser` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-29 12:51:49
